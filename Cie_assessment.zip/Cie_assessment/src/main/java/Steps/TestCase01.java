package Steps;
import org.openqa.selenium.*;

public class TestCase01 {
public static void main(String[] args){
    WebDriver driver = ("WebDriver.chrome.driver", "pathToDriver/chrome.driver");
    driver.get(url);
    thread.sleep(2000);

    WebElement primaryScreen = driver.getWindowHandle();
    primaryScreen.isDisplayed();

}
}
